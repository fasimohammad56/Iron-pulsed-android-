# IronPulse — Android fitness tracker

A native Android starter app inspired by modern fitness trackers, with an original name and visual identity.

## Included in version 1
- Dark premium UI with lime accent
- Home dashboard with calorie/protein progress
- Workout exercise log (sets, reps, weight, notes)
- Food log with manually entered calories and protein
- Water-glass counter
- Editable daily calorie and protein targets
- Body-weight history
- Local persistence using Android SharedPreferences
- No account or network permission required

## Build an installable APK
This environment did not have the Android SDK or Gradle installed, so the APK was not compiled or tested here.

1. Install **Android Studio** on a computer.
2. Extract this project ZIP.
3. In Android Studio, choose **Open** and select the `IronPulseAndroid` folder.
4. Allow Gradle sync. Install Android SDK Platform 35 if prompted.
5. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. When the build finishes, click **locate** in the notification. The APK is usually at:
   `app/build/outputs/apk/debug/app-debug.apk`
7. Transfer the APK to your Android phone and open it. You may need to allow installation from that source.

## Notes
- Package ID: `com.ironpulse.fitness`
- Minimum Android version: Android 7.0 (API 24)
- App data is stored locally on the device.
- Food values are entered manually; this version does not include a verified food database, barcode scanning, cloud sync, or AI coach.
- The daily nutrition reset resets today's calories/protein and food list. It does not erase workout history or weight history.
- This is an initial MVP. Please build and test before relying on it for daily tracking.
