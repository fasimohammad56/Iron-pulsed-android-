package com.ironpulse.fitness

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

private val Bg = Color(0xFF090B0E)
private val Panel = Color(0xFF15191F)
private val Panel2 = Color(0xFF1D232B)
private val Lime = Color(0xFFC6F36A)
private val Muted = Color(0xFF9BA5B1)
private val White = Color(0xFFF5F7F8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("ironpulse_data", MODE_PRIVATE)
        setContent {
            var tab by remember { mutableStateOf("Home") }
            var calorieGoal by remember { mutableIntStateOf(prefs.getInt("goal", 2400)) }
            var proteinGoal by remember { mutableIntStateOf(prefs.getInt("protein_goal", 150)) }
            var calories by remember { mutableIntStateOf(prefs.getInt("calories", 0)) }
            var protein by remember { mutableIntStateOf(prefs.getInt("protein", 0)) }
            var water by remember { mutableIntStateOf(prefs.getInt("water", 0)) }
            var weight by remember { mutableStateOf(prefs.getString("weight", "") ?: "") }
            var meals by remember { mutableStateOf(loadList(prefs.getString("meals", "[]") ?: "[]")) }
            var workouts by remember { mutableStateOf(loadList(prefs.getString("workouts", "[]") ?: "[]")) }
            var weights by remember { mutableStateOf(loadList(prefs.getString("weights", "[]") ?: "[]")) }

            fun save() {
                prefs.edit().putInt("goal", calorieGoal).putInt("protein_goal", proteinGoal)
                    .putInt("calories", calories).putInt("protein", protein).putInt("water", water)
                    .putString("weight", weight).putString("meals", JSONArray(meals).toString())
                    .putString("workouts", JSONArray(workouts).toString())
                    .putString("weights", JSONArray(weights).toString()).apply()
            }

            MaterialTheme(colorScheme = darkColorScheme(
                primary = Lime, background = Bg, surface = Panel, onSurface = White,
                onBackground = White, secondary = Lime
            )) {
                Column(Modifier.fillMaxSize().background(Bg)) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("IRONPULSE", color = Lime, fontSize = 12.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                            Text("Train with purpose.", color = White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                        }
                        Box(Modifier.size(42.dp).background(Panel2, CircleShape), contentAlignment = Alignment.Center) {
                            Text("IP", color = Lime, fontWeight = FontWeight.Black)
                        }
                    }
                    Box(Modifier.weight(1f)) {
                        when (tab) {
                            "Home" -> HomeScreen(calories, calorieGoal, protein, proteinGoal, water, workouts.size,
                                onAddWater = { water += 1; save() }, onGoWorkout = { tab = "Workouts" },
                                onGoFood = { tab = "Nutrition" })
                            "Workouts" -> WorkoutScreen(workouts, onAdd = { workouts = workouts + it; save() })
                            "Nutrition" -> NutritionScreen(meals, calories, protein, calorieGoal, proteinGoal,
                                onAdd = { name, cals, prot ->
                                    meals = meals + "$name • ${cals} kcal • ${prot}g protein"
                                    calories += cals; protein += prot; save()
                                },
                                onReset = { calories = 0; protein = 0; meals = emptyList(); save() })
                            else -> ProgressScreen(weight, weights, calorieGoal, proteinGoal,
                                onWeightChange = { weight = it; save() },
                                onSaveWeight = {
                                    if (weight.isNotBlank()) { weights = weights + "${weight} kg"; save() }
                                },
                                onGoalsChange = { c, p -> calorieGoal = c; proteinGoal = p; save() })
                        }
                    }
                    NavigationBar(containerColor = Panel, contentColor = Muted) {
                        listOf("Home", "Workouts", "Nutrition", "Progress").forEach { item ->
                            NavigationBarItem(
                                selected = tab == item,
                                onClick = { tab = item },
                                icon = { Text(when(item) { "Home" -> "⌂"; "Workouts" -> "✦"; "Nutrition" -> "◉"; else -> "↗" }, fontSize = 20.sp) },
                                label = { Text(item, fontSize = 10.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Lime, selectedTextColor = Lime,
                                    indicatorColor = Panel2, unselectedIconColor = Muted, unselectedTextColor = Muted
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun loadList(raw: String): List<String> = try {
    val a = JSONArray(raw)
    (0 until a.length()).map { a.getString(it) }
} catch (_: Exception) { emptyList() }

@Composable
private fun HomeScreen(
    calories: Int, calorieGoal: Int, protein: Int, proteinGoal: Int, water: Int, workouts: Int,
    onAddWater: () -> Unit, onGoWorkout: () -> Unit, onGoFood: () -> Unit
) {
    LazyColumn(contentPadding = PaddingValues(horizontal = 18.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Lime), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    Text("YOUR DAILY MISSION", color = Color(0xFF303A1C), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("Build strength.\nOwn the process.", color = Color(0xFF10140B), fontSize = 27.sp, lineHeight = 31.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.height(14.dp))
                    Text("Small wins compound. Show up today.", color = Color(0xFF303A1C), fontSize = 13.sp)
                }
            }
        }
        item { SectionHeading("TODAY AT A GLANCE", "Daily totals") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MetricCard("CALORIES", "$calories", "of $calorieGoal kcal", Modifier.weight(1f))
                MetricCard("PROTEIN", "${protein}g", "of ${proteinGoal}g", Modifier.weight(1f))
            }
        }
        item {
            val calPct = (calories.toFloat() / calorieGoal.coerceAtLeast(1)).coerceIn(0f, 1f)
            val proPct = (protein.toFloat() / proteinGoal.coerceAtLeast(1)).coerceIn(0f, 1f)
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    ProgressLine("Calorie goal", calPct, "$calories / $calorieGoal kcal")
                    ProgressLine("Protein goal", proPct, "$protein / $proteinGoal g")
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Card(Modifier.weight(1f).clickable(onClick = onAddWater), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("WATER", color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
                        Spacer(Modifier.height(8.dp))
                        Text("$water glasses", color = White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                        Text("+ Add a glass", color = Lime, fontSize = 12.sp)
                    }
                }
                Card(Modifier.weight(1f).clickable(onClick = onGoWorkout), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("WORKOUTS", color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
                        Spacer(Modifier.height(8.dp))
                        Text("$workouts logged", color = White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                        Text("Open tracker →", color = Lime, fontSize = 12.sp)
                    }
                }
            }
        }
        item {
            Button(onClick = onGoFood, modifier = Modifier.fillMaxWidth().height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Bg), shape = RoundedCornerShape(16.dp)) {
                Text("+ LOG FOOD", fontWeight = FontWeight.Black, letterSpacing = 1.sp)
            }
        }
    }
}

@Composable
private fun WorkoutScreen(workouts: List<String>, onAdd: (String) -> Unit) {
    var exercise by remember { mutableStateOf("") }
    var sets by remember { mutableStateOf("3") }
    var reps by remember { mutableStateOf("10") }
    var weight by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    LazyColumn(contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { SectionHeading("TRAINING LOG", "Workout tracker") }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    AppField("Exercise name", exercise, { exercise = it }, "e.g. Bench press")
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(Modifier.weight(1f)) { AppField("Sets", sets, { sets = it }, "3", true) }
                        Box(Modifier.weight(1f)) { AppField("Reps", reps, { reps = it }, "10", true) }
                        Box(Modifier.weight(1f)) { AppField("Weight kg", weight, { weight = it }, "40", true) }
                    }
                    AppField("Note (optional)", note, { note = it }, "Felt strong today")
                    Button(
                        onClick = {
                            if (exercise.isNotBlank()) {
                                onAdd("${exercise.trim()} • ${sets.ifBlank { "3" }} sets × ${reps.ifBlank { "10" }} reps • ${weight.ifBlank { "0" }} kg" + if (note.isNotBlank()) " • $note" else "")
                                exercise = ""; weight = ""; note = ""
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Bg),
                        shape = RoundedCornerShape(14.dp)
                    ) { Text("SAVE EXERCISE", fontWeight = FontWeight.Black) }
                }
            }
        }
        item { SectionHeading("RECENT ACTIVITY", "${workouts.size} entries") }
        if (workouts.isEmpty()) item { EmptyState("No exercises logged yet", "Add your first exercise above.") }
        items(workouts.reversed()) { EntryCard(it, "TRAINING") }
    }
}

@Composable
private fun NutritionScreen(
    meals: List<String>, calories: Int, protein: Int, calorieGoal: Int, proteinGoal: Int,
    onAdd: (String, Int, Int) -> Unit, onReset: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    var cals by remember { mutableStateOf("") }
    var prot by remember { mutableStateOf("") }
    LazyColumn(contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { SectionHeading("FUEL YOUR GOALS", "Nutrition tracker") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MetricCard("CALORIES", "$calories", "goal $calorieGoal kcal", Modifier.weight(1f))
                MetricCard("PROTEIN", "${protein}g", "goal ${proteinGoal}g", Modifier.weight(1f))
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Add food", color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    AppField("Food / meal", name, { name = it }, "e.g. Oats with milk")
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(Modifier.weight(1f)) { AppField("Calories", cals, { cals = it }, "350", true) }
                        Box(Modifier.weight(1f)) { AppField("Protein (g)", prot, { prot = it }, "20", true) }
                    }
                    Text("Use nutrition labels or a trusted food database for accurate values.", color = Muted, fontSize = 11.sp)
                    Button(
                        onClick = {
                            val cv = cals.toIntOrNull(); val pv = prot.toIntOrNull()
                            if (name.isNotBlank() && cv != null && pv != null && cv >= 0 && pv >= 0) {
                                onAdd(name.trim(), cv, pv); name = ""; cals = ""; prot = ""
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Bg),
                        shape = RoundedCornerShape(14.dp)
                    ) { Text("ADD TO TODAY", fontWeight = FontWeight.Black) }
                }
            }
        }
        item { SectionHeading("TODAY'S FOOD", "${meals.size} items") }
        if (meals.isEmpty()) item { EmptyState("Your food log is empty", "Add a meal to start tracking.") }
        items(meals.reversed()) { EntryCard(it, "NUTRITION") }
        if (meals.isNotEmpty()) item {
            OutlinedButton(onClick = onReset, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = Lime)) {
                Text("Reset today's nutrition")
            }
        }
    }
}

@Composable
private fun ProgressScreen(
    weight: String, weights: List<String>, calorieGoal: Int, proteinGoal: Int,
    onWeightChange: (String) -> Unit, onSaveWeight: () -> Unit, onGoalsChange: (Int, Int) -> Unit
) {
    var calInput by remember(calorieGoal) { mutableStateOf(calorieGoal.toString()) }
    var proInput by remember(proteinGoal) { mutableStateOf(proteinGoal.toString()) }
    LazyColumn(contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { SectionHeading("YOUR JOURNEY", "Progress & goals") }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Daily targets", color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    AppField("Calorie goal (kcal)", calInput, { calInput = it }, "2400", true)
                    AppField("Protein goal (g)", proInput, { proInput = it }, "150", true)
                    Button(onClick = {
                        val c = calInput.toIntOrNull(); val p = proInput.toIntOrNull()
                        if (c != null && p != null && c > 0 && p > 0) onGoalsChange(c, p)
                    }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Bg)) {
                        Text("SAVE GOALS", fontWeight = FontWeight.Black)
                    }
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Body weight", color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    AppField("Current weight (kg)", weight, onWeightChange, "e.g. 68.5", true)
                    Button(onClick = onSaveWeight, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Panel2, contentColor = Lime)) {
                        Text("SAVE WEIGHT ENTRY")
                    }
                }
            }
        }
        item { SectionHeading("WEIGHT HISTORY", "${weights.size} entries") }
        if (weights.isEmpty()) item { EmptyState("No weight entries yet", "Save your weight to begin tracking trends.") }
        items(weights.reversed()) { EntryCard(it, "BODY WEIGHT") }
        item {
            Text("Tip: weigh yourself under similar conditions each time. Day-to-day changes are normal; watch the longer-term trend.", color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun SectionHeading(kicker: String, title: String) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(kicker, color = Lime, fontSize = 10.sp, letterSpacing = 1.7.sp, fontWeight = FontWeight.Bold)
        Text(title, color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun MetricCard(label: String, value: String, detail: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(label, color = Muted, fontSize = 10.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(value, color = White, fontSize = 25.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(3.dp))
            Text(detail, color = Lime, fontSize = 11.sp)
        }
    }
}

@Composable
private fun ProgressLine(label: String, fraction: Float, detail: String) {
    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text(detail, color = Muted, fontSize = 11.sp)
        }
        LinearProgressIndicator(
            progress = { fraction }, modifier = Modifier.fillMaxWidth().height(7.dp),
            color = Lime, trackColor = Panel2
        )
    }
}

@Composable
private fun AppField(label: String, value: String, onValue: (String) -> Unit, placeholder: String, numeric: Boolean = false) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(label, color = Muted, fontSize = 12.sp)
        OutlinedTextField(
            value = value, onValueChange = onValue, modifier = Modifier.fillMaxWidth(),
            placeholder = { Text(placeholder, color = Muted.copy(alpha = 0.65f), fontSize = 13.sp) },
            singleLine = true,
            keyboardOptions = if (numeric) KeyboardOptions(keyboardType = KeyboardType.Number) else KeyboardOptions.Default,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Lime, unfocusedBorderColor = Panel2,
                focusedTextColor = White, unfocusedTextColor = White,
                cursorColor = Lime, focusedContainerColor = Bg, unfocusedContainerColor = Bg
            ),
            shape = RoundedCornerShape(13.dp)
        )
    }
}

@Composable
private fun EntryCard(text: String, tag: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(36.dp).background(Panel2, CircleShape), contentAlignment = Alignment.Center) {
                Text(if (tag == "TRAINING") "✦" else if (tag == "NUTRITION") "◉" else "↗", color = Lime)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(text, color = White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Text(tag, color = Muted, fontSize = 9.sp, letterSpacing = 1.2.sp)
            }
        }
    }
}

@Composable
private fun EmptyState(title: String, detail: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("＋", color = Lime, fontSize = 26.sp)
            Spacer(Modifier.height(5.dp))
            Text(title, color = White, fontWeight = FontWeight.Bold)
            Text(detail, color = Muted, fontSize = 12.sp)
        }
    }
}
